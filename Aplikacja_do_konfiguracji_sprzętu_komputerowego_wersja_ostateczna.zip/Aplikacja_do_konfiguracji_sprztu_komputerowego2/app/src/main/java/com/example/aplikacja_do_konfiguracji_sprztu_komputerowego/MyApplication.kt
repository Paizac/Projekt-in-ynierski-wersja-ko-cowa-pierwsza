package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.app.Application
import androidx.lifecycle.ViewModelProvider


class MyApplication : Application() {
    val cartViewModel: CartViewModel by lazy {
        ViewModelProvider.AndroidViewModelFactory.getInstance(this)
            .create(CartViewModel::class.java)
    }
}


