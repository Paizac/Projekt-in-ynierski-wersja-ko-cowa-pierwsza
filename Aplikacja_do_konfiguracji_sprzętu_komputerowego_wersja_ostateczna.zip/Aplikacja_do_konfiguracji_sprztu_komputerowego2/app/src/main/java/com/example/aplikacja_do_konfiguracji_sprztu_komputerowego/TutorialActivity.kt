package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import okhttp3.MediaType
import okhttp3.RequestBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

class TutorialActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private var lastResponse: String? = null
    private val sharedPreferencesKey = "lastResponse"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutorial)

        val etQuestion = findViewById<EditText>(R.id.etQuesstion)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val txtResponse = findViewById<TextView>(R.id.txtResponse)

        // Dodaj przycisk "Komponenty"
        val componentsButton = findViewById<Button>(R.id.componentsButton)
        componentsButton.setOnClickListener {
            navigateToComponentsActivity()
        }

        // Wyświetl ostatnią odpowiedź (jeśli istnieje)
        if (lastResponse != null) {
            txtResponse.text = lastResponse
        }

        // Wczytaj ostatnią odpowiedź z pamięci podręcznej
        lastResponse = loadLastResponse()
        if (lastResponse != null) {
            txtResponse.text = lastResponse
        }

        btnSubmit.setOnClickListener {
            val question = etQuestion.text.toString()
            Toast.makeText(this, question, Toast.LENGTH_SHORT).show()
            getResponse(question) { response ->
                runOnUiThread {
                    // Zapisz ostatnią odpowiedź
                    lastResponse = response
                    txtResponse.text = response

                    // Zapisz ostatnią odpowiedź w pamięci podręcznej
                    saveLastResponse(response)
                }
            }
        }
    }

    private fun saveLastResponse(response: String) {
        val sharedPreferences = getSharedPreferences(sharedPreferencesKey, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(sharedPreferencesKey, response)
        editor.apply()
    }

    private fun loadLastResponse(): String? {
        val sharedPreferences = getSharedPreferences(sharedPreferencesKey, Context.MODE_PRIVATE)
        return sharedPreferences.getString(sharedPreferencesKey, null)
    }

    private fun navigateToComponentsActivity() {
        val intent = Intent(this, ComponentsActivity::class.java)
        startActivity(intent)
    }

    private fun getResponse(question: String, callback: (String) -> Unit) {
        val apiKey = "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"
        val url = "https://api.openai.com/v1/engines/gpt-3.5-turbo-instruct/completions"

        val requestBody = """
            {
                "prompt": "$question",
                "max_tokens": 500,
                "temperature": 0
            }
        """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("error", "API failed", e)
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (body != null) {
                    Log.v("data", body)
                    try {
                        val jsonObject = JSONObject(body)
                        val jsonArray: JSONArray = jsonObject.getJSONArray("choices")
                        val textResult = jsonArray.getJSONObject(0).getString("text")
                        callback(textResult)
                    } catch (e: Exception) {
                        Log.e("error", "Error parsing JSON", e)
                    }
                } else {
                    Log.v("data", "empty")
                }
            }
        })
    }
    override fun onDestroy() {
        // Wyczyść ostatnią odpowiedź przed zniszczeniem aktywności
        clearLastResponse()
        super.onDestroy()
    }

    private fun clearLastResponse() {
        lastResponse = null

        // Wyczyść ostatnią odpowiedź także z pamięci podręcznej
        clearLastResponseFromCache()
    }

    private fun clearLastResponseFromCache() {
        val sharedPreferences = getSharedPreferences(sharedPreferencesKey, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove(sharedPreferencesKey)
        editor.apply()
    }
}
