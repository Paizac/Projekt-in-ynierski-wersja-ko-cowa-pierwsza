import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aplikacja_do_konfiguracji_sprztu_komputerowego.Component
import com.example.aplikacja_do_konfiguracji_sprztu_komputerowego.R

class CartAdapter(
    private val context: Context,
    private val cartList: List<Component>,
    private val onRemoveClickListener: (Int) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val componentName: TextView = itemView.findViewById(R.id.componentName)
        val componentPrice: TextView = itemView.findViewById(R.id.componentPrice)
        val removeButton: ImageButton = itemView.findViewById(R.id.removeButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val itemView =
            LayoutInflater.from(context).inflate(R.layout.cart_item, parent, false)
        return CartViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val component = cartList[position]

        holder.componentName.text = component.name
        holder.componentPrice.text = component.price_usd

        // Obsługa kliknięcia przycisku usuwania
        holder.removeButton.setOnClickListener {
            if (position >= 0 && position < cartList.size) {
                onRemoveClickListener.invoke(position)
            }
        }
    }

    override fun getItemCount(): Int {
        return cartList.size
    }
}
