package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONException
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import java.io.*
import androidx.appcompat.widget.SearchView
import android.widget.ListView


data class Component(
    val name: String,
    val price_usd: String,
    val type: String?,
    val core_clock: String?,
    val boost_clock: String?,
    val core_count: String?,
    val tdp: String?,
): Serializable

class MainActivity : AppCompatActivity() {
    private var isHomePage: Boolean = true
    private lateinit var jsonList: ListView
    private val componentList = ArrayList<Component>()
    private val cartList = ArrayList<Component>()
    private lateinit var cartViewModel: CartViewModel
    private lateinit var searchView: SearchView
    private lateinit var tutorialButton: Button // Dodaj to pole
    private val fullComponentList = ArrayList<Component>()

    private val REQUEST_CART = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        jsonList = findViewById(R.id.json_list)
        val appLogo = findViewById<ImageView>(R.id.appLogo)
        val appName = findViewById<TextView>(R.id.appName)
        tutorialButton = findViewById<Button>(R.id.tutorialButton) // Zainicjalizuj przycisk
        searchView = findViewById(R.id.searchView)

        val selectedCategory = intent.getStringExtra("selectedCategory")
        if (selectedCategory != null) {
            readJsonFile(selectedCategory)
            isHomePage = false
        }

        appLogo.visibility = if (isHomePage) View.VISIBLE else View.GONE
        appName.visibility = if (isHomePage) View.GONE else View.GONE
        tutorialButton.visibility = View.VISIBLE

        // Ukryj lub pokaż pole wyszukiwania w zależności od tego, czy jesteś w kategorii komponentów
        if (isHomePage) {
            searchView.visibility = View.GONE
        } else {
            searchView.visibility = View.VISIBLE
        }

        val componentAdapter = ComponentAdapter(this, R.layout.component_item, componentList)
        jsonList.adapter = componentAdapter

        fullComponentList.addAll(componentList)


        val componentsButton = findViewById<Button>(R.id.componentsButton)
        componentsButton.setOnClickListener {
            val intent = Intent(this, ComponentsActivity::class.java)
            startActivity(intent)
        }

        val shoppingCartIcon = findViewById<ImageView>(R.id.shoppingCartIcon)
        shoppingCartIcon.setOnClickListener {
            onShoppingCartClick()
        }

        val tutorialButton = findViewById<Button>(R.id.tutorialButton)
        tutorialButton.setOnClickListener {
            val intent = Intent(this, TutorialActivity::class.java)
            startActivity(intent)
        }

        cartViewModel = (application as MyApplication).cartViewModel

        searchView = findViewById(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterComponentList(newText)
                return true
            }
        })
    }

    private fun filterComponentList(query: String?) {
        if (query.isNullOrBlank()) {
            // Jeśli zapytanie jest puste, przywracamy pełną listę
            (jsonList.adapter as? ComponentAdapter)?.updateList(fullComponentList)
        } else {
            val pattern = query.toRegex(RegexOption.IGNORE_CASE)
            val filteredList = fullComponentList.filter {
                pattern.containsMatchIn(it.name)
            }

            (jsonList.adapter as? ComponentAdapter)?.updateList(filteredList)
        }
    }


    private fun onShoppingCartClick() {
        val intent = Intent(this, CartActivity::class.java)
        intent.putExtra("cartList", cartViewModel.cartList as Serializable)
        startActivityForResult(intent, REQUEST_CART)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CART && resultCode == Activity.RESULT_OK) {
            val updatedCartList = data?.getSerializableExtra("updatedCartList") as? MutableList<Component>
            if (updatedCartList != null) {
                cartViewModel.cartList.clear()
                cartViewModel.cartList.addAll(updatedCartList)
                (jsonList.adapter as? ComponentAdapter)?.notifyDataSetChanged()

                if (updatedCartList.isEmpty()) {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
            } else {
                Log.e("MainActivity", "Updated cart list is null")
            }
        }
    }

    private fun readJsonFile(category: String) {
        try {
            val filename = getCategoryFileName(category)
            val inputStream: InputStream = assets.open(filename)
            val json = BufferedReader(InputStreamReader(inputStream)).use { it.readText() }

            val jsonArray = JSONArray(json)

            componentList.clear()
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val componentName = jsonObject.optString("name", "")
                val componentPrice = jsonObject.optString("price_usd", "")
                val componentType = jsonObject.optString("type", null)
                val componentCoreClock = jsonObject.optString("core_clock", null)
                val componentBoostClock = jsonObject.optString("boost_clock", null)
                val componentCoreCount = jsonObject.optString("core_count", null)
                val componentTdp = jsonObject.optString("tdp", null)

                if (!componentPrice.isNullOrBlank() && componentPrice != "null") {
                    val componentInfo = Component(
                        componentName,
                        componentPrice,
                        componentType,
                        componentCoreClock,
                        componentBoostClock,
                        componentCoreCount,
                        componentTdp
                    )
                    componentList.add(componentInfo)
                }
            }

            (jsonList.adapter as? ComponentAdapter)?.notifyDataSetChanged()
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    private fun getCategoryFileName(category: String): String {
        return when (category) {
            "Komponenty" -> "komponenty.json"
            "Obudowa" -> "case.json"
            "Procesor" -> "cpu.json"
            "Chłodzenie" -> "cpu-cooler.json"
            "Płyta główna" -> "motherboard.json"
            "Pamięć RAM" -> "memory.json"
            "Karta graficzna" -> "video-card.json"
            "Dysk" -> "external-hard-drive.json"
            "Zasilacz" -> "power-supply.json"
            else -> ""
        }
    }

    inner class ComponentAdapter(
        context: Context,
        private val resource: Int,
        private val components: List<Component>
    ) : ArrayAdapter<Component>(context, resource, components) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val inflater = LayoutInflater.from(context)
            val view = inflater.inflate(resource, parent, false)

            val componentName = view.findViewById<TextView>(R.id.componentName)
            val componentType = view.findViewById<TextView>(R.id.componentType)
            val componentPrice = view.findViewById<TextView>(R.id.componentPrice)

            val addToCartButton = view.findViewById<Button>(R.id.addToCartButton)
            addToCartButton.text = "Dodaj do koszyka"
            addToCartButton.setOnClickListener {
                addToCart(components[position])
            }

            val detailsButton = view.findViewById<Button>(R.id.detailsButton)
            val component = components[position]

            componentName.text = component.name
            componentType.text = component.type
            componentPrice.text = component.price_usd

            detailsButton.text = "Szczegóły"

            detailsButton.setOnClickListener {
                showComponentDetails(component)
            }

            return view
        }

        fun updateList(newList: List<Component>) {
            clear()
            addAll(newList)
            notifyDataSetChanged()
        }
    }

    private fun addToCart(component: Component) {
        cartViewModel.cartList.add(component)
        (jsonList.adapter as? ComponentAdapter)?.notifyDataSetChanged()
        showAddedToCartMessage(component)
    }

    private fun showComponentDetails(component: Component) {
        val detailsDialog = AlertDialog.Builder(this)
            .setTitle("Szczegóły komponentu")
            .setMessage(buildComponentDetailsMessage(component))
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        detailsDialog.show()
    }

    private fun buildComponentDetailsMessage(component: Component): String {
        val message = StringBuilder()

        message.append("Nazwa: ${component.name}\n")

        if (!component.price_usd.isNullOrBlank() && component.price_usd != "null") {
            message.append("Cena: ${component.price_usd}$\n")
        } else {
            message.append("Cena: Brak dostępnej ceny\n")
        }

        if (!component.type.isNullOrBlank()) {
            message.append("Typ: ${component.type}\n")
        }

        if (!component.core_clock.isNullOrBlank()) {
            message.append("Częstotliwość taktowania: ${component.core_clock}\n")
        }

        if (!component.boost_clock.isNullOrBlank()) {
            message.append("Podkręcone taktowanie: ${component.boost_clock}\n")
        }

        if (!component.core_count.isNullOrBlank()) {
            message.append("Ilość rdzeni: ${component.core_count}\n")
        }
        if (!component.tdp.isNullOrBlank()) {
            message.append("Zasilanie: ${component.tdp}\n")
        }

        return message.toString()
    }

    private fun showAddedToCartMessage(component: Component) {
        val addedToCartDialog = AlertDialog.Builder(this)
            .setTitle("Dodano do koszyka")
            .setMessage("Komponent ${component.name} został dodany do koszyka.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        addedToCartDialog.show()
    }
}
