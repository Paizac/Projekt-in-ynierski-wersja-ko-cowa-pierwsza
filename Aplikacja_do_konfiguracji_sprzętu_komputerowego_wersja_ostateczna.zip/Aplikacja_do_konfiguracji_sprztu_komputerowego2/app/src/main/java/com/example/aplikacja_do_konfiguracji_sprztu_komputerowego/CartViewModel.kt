package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import androidx.lifecycle.ViewModel

class CartViewModel : ViewModel() {
    val cartList = mutableListOf<Component>()
}