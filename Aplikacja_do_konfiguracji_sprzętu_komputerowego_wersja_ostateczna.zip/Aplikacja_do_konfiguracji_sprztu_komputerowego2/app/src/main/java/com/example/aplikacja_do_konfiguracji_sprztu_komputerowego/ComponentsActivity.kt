package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ComponentsActivity : AppCompatActivity() {
    companion object {
        const val YOUR_REQUEST_CODE = 123 // Możesz użyć dowolnej liczby całkowitej
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_components)

        val cpuButton = findViewById<Button>(R.id.cpuButton)
        val gpuButton = findViewById<Button>(R.id.gpuButton)
        val caseButton = findViewById<Button>(R.id.caseButton)
        val coolerButton = findViewById<Button>(R.id.coolerButton)
        val motherboardButton = findViewById<Button>(R.id.motherboardButton)
        val memoryButton = findViewById<Button>(R.id.memoryButton)
        val storageButton = findViewById<Button>(R.id.storageButton)
        val powerSupplyButton = findViewById<Button>(R.id.powerSupplyButton)

        cpuButton.setOnClickListener {
            startCategoryActivity("Procesor")
        }

        gpuButton.setOnClickListener {
            startCategoryActivity("Karta graficzna")
        }

        caseButton.setOnClickListener {
            startCategoryActivity("Obudowa")
        }

        coolerButton.setOnClickListener {
            startCategoryActivity("Chłodzenie")
        }

        motherboardButton.setOnClickListener {
            startCategoryActivity("Płyta główna")
        }

        memoryButton.setOnClickListener {
            startCategoryActivity("Pamięć RAM")
        }

        storageButton.setOnClickListener {
            startCategoryActivity("Dysk")
        }

        powerSupplyButton.setOnClickListener {
            startCategoryActivity("Zasilacz")
        }
    }

    private fun startCategoryActivity(category: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("selectedCategory", category)
        startActivityForResult(intent, YOUR_REQUEST_CODE)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == YOUR_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val updatedCartList = data?.getSerializableExtra("updatedCartList") as? ArrayList<Component>
            updatedCartList?.let {
                // Zaktualizuj listę komponentów na podstawie odebranej listy
                // (jeśli potrzebujesz dostępu do tej listy w przyszłości)
            }
        }
    }
}
