package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ComponentsForCategoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_components_for_category)

    }
}
