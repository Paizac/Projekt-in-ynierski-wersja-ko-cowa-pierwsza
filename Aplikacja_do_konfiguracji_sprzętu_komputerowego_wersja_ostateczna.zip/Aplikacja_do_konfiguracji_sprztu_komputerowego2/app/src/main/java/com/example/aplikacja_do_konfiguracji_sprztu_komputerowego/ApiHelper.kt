package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import android.util.Log
import com.google.gson.Gson
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException


class ApiHelper {
    companion object {
        private val client = OkHttpClient()

        fun getResponse(question: String, cartList: List<Component>, callback: (String) -> Unit) {
            val apiKey = "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"
            val url = "https://api.openai.com/v1/engines/gpt-3.5-turbo-instruct/completions"

            // Dodaj listę komponentów do kontekstu pytania
            val promptWithCart = buildPrompt(question, cartList)
            Log.d("Prompt", promptWithCart)

            // Utwórz obiekt JSON z danymi do wysłania
            val requestBody = mapOf(
                "prompt" to promptWithCart,
                "max_tokens" to 500,
                "temperature" to 0
            )

            val json = Gson().toJson(requestBody)
            val request = Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(json.toRequestBody("application/json".toMediaTypeOrNull()))
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("error", "API failed", e)
                    callback("API failed: ${e.message}")
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    if (body != null) {
                        Log.v("data", body)
                        try {
                            val jsonObject = JSONObject(body)
                            if (jsonObject.has("choices")) {
                                val jsonArray: JSONArray = jsonObject.getJSONArray("choices")
                                if (jsonArray.length() > 0 && jsonArray.getJSONObject(0).has("text")) {
                                    val textResult = jsonArray.getJSONObject(0).getString("text")
                                    callback(textResult)
                                    return
                                }
                            }
                            Log.e("error", "Invalid response format")
                            callback("Invalid response format")
                        } catch (e: Exception) {
                            Log.e("error", "Error parsing JSON", e)
                            callback("Error parsing JSON: ${e.message}")
                        }
                    } else {
                        Log.v("data", "empty")
                        callback("Empty response from API")
                    }
                }
            })
        }

        private fun buildPrompt(question: String, cartList: List<Component>): String {
            val cartPrompt = cartList.joinToString("\n") { " - ${it.name}: $${it.price_usd}" }
            return "$question\n\nLista komponentów w koszyku:\n$cartPrompt"
        }
    }
}
