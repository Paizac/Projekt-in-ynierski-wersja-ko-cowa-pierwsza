package com.example.aplikacja_do_konfiguracji_sprztu_komputerowego

import CartAdapter
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import java.io.Serializable

class CartActivity : AppCompatActivity() {
    private lateinit var cartViewModel: CartViewModel
    private lateinit var cartList: MutableList<Component>
    private var isPaymentCompleted: Boolean = false
    private lateinit var cartRecyclerView: RecyclerView

    // Dodaj EditText i TextView
    private lateinit var questionEditText: EditText
    private lateinit var apiResponseTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        // Inicjalizacja ViewModel
        cartViewModel = ViewModelProvider(this).get(CartViewModel::class.java)

        // Odbierz listę komponentów z intencji
        cartList = intent.getSerializableExtra("cartList") as MutableList<Component>? ?: mutableListOf()

        // Inicjalizacja RecyclerView
        cartRecyclerView = findViewById(R.id.cartRecyclerView)
        val cartAdapter = CartAdapter(this, cartList) { position ->
            // Obsługa kliknięcia przycisku "Usuń"
            removeItemFromCart(position)
        }
        cartRecyclerView.adapter = cartAdapter
        cartRecyclerView.layoutManager = LinearLayoutManager(this)

        updateTotalPrice(cartList)

        // Inicjalizacja widoków dodanych do layoutu
        questionEditText = findViewById(R.id.questionEditText)
        apiResponseTextView = findViewById(R.id.apiResponseTextView)

        // Dodaj obsługę przycisku sprawdzenia kompatybilności
        val checkCompatibilityButton: Button = findViewById(R.id.checkCompatibilityButton)
        checkCompatibilityButton.setOnClickListener {
            val question = questionEditText.text.toString()

            // Sprawdź kompatybilność z API, przekazując listę komponentów bezpośrednio
            ApiHelper.getResponse(question, cartList) { response ->
                // Aktualizuj widok w głównym wątku
                runOnUiThread {
                    apiResponseTextView.text = response
                }
            }
        }

        // Ustaw początkową listę komponentów w ViewModel
        cartViewModel.cartList.addAll(cartList)

        // Dodaj obsługę przycisku powrotu do komponentów
        val backToComponentsButton: Button = findViewById(R.id.backToComponentsButton)
        backToComponentsButton.setOnClickListener {
            val intent = Intent()
            intent.putExtra("updatedCartList", ArrayList(cartList))
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        // Dodaj obsługę przycisku zapłaty
        val payButton: Button = findViewById(R.id.payButton)
        payButton.setOnClickListener {
            // Po kliknięciu "Zapłać" zwracamy do MainActivity pusty koszyk
            isPaymentCompleted = true
            sendUpdatedCartList(emptyList())

            // Wyświetlenie komunikatu
            Toast.makeText(this, "Dziękujemy za zakupy!", Toast.LENGTH_SHORT).show()

            // Aktualizuj cenę po płatności
            updateTotalPrice(emptyList())
        }
    }

    private fun sendUpdatedCartList(updatedCartList: List<Component>) {
        // Zapisz aktualizacje w lokalnej zmiennej
        cartList.clear()
        cartList.addAll(updatedCartList)

        val intent = Intent()
        intent.putExtra("updatedCartList", ArrayList(cartList))
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun updateTotalPrice(cartList: List<Component>) {
        val totalPriceTextView: TextView = findViewById(R.id.totalPrice)
        val totalPrice = calculateTotalPrice(cartList)
        Log.d("CartActivity", "Total Price: $$totalPrice")
        totalPriceTextView.text = "Total Price: $$totalPrice"
    }

    private fun calculateTotalPrice(cartList: List<Component>): Double {
        var totalPrice = 0.0
        for (component in cartList) {
            component.price_usd.toDoubleOrNull()?.let {
                totalPrice += it
            }
        }
        return totalPrice
    }

    private fun removeItemFromCart(position: Int) {
        if (position >= 0 && position < cartList.size) {
            cartList.removeAt(position)

            // Aktualizuj ViewModel
            cartViewModel.cartList.clear()
            cartViewModel.cartList.addAll(cartList)

            // Aktualizuj cenę po usunięciu elementu
            updateTotalPrice(cartList)

            // Aktualizuj adapter
            cartRecyclerView.adapter?.notifyDataSetChanged()
        }
    }
}

